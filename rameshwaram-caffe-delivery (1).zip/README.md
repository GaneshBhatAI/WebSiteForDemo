# Rameshwaram Caffe Delivery App

A premium food delivery web application for **Rameshwaram Caffe**, built with React, Vite, and Tailwind CSS. Experience the authentic taste of South India with a seamless ordering experience.

## 🚀 Features

- **Authentic Menu**: Browse through signature categories like Ghee Podi Idli, Dosa, and authentic Filter Coffee.
- **Dynamic Cart**: Add, remove, and manage items in your cart with real-time price calculations.
- **Secure Payment**: Integrated PhonePe/UPI deep linking (9483715866@ybl) for instant mobile payments.
- **Responsive Design**: Fully optimized for mobile, tablet, and desktop viewing.
- **Smooth Animations**: Powered by `motion` for a polished, high-end feel.

## 🛠️ Tech Stack

- **Frontend**: React 19, TypeScript
- **Styling**: Tailwind CSS
- **Animations**: Motion (formerly Framer Motion)
- **Icons**: Lucide React
- **Build Tool**: Vite

## 📦 Installation

To run this project locally:

1. Clone the repository:
   ```bash
   git clone <your-repo-url>
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm run dev
   ```

## 🌐 Deployment

### 1. Push to GitHub
Push your code to the `main` branch of your GitHub repository.

### 2. Configure GitHub Pages (CRITICAL)
To avoid a white screen, you must change one setting in your GitHub repository:
1. Go to your repository on GitHub.com.
2. Click on **Settings** (top tab).
3. Click on **Pages** in the left sidebar.
4. Under **Build and deployment** > **Source**, change from "Deploy from a branch" to **"GitHub Actions"**.

After this change, any push to `main` will automatically build and publish your site perfectly.

---

Built with ❤️ for Rameshwaram Caffe.
